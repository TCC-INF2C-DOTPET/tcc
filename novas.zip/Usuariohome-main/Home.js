$(document).ready(function(){
  $('.carrossel').slick({
    arrows: true, // Mostra setas de navegação (anterior/próximo)
    dots: true, // Mostra pontos de navegação
    autoplay: true, // Inicia a reprodução automática
    autoplaySpeed: 1000, // Velocidade da reprodução automática em milissegundos (2 segundos)
    infinite: true, // Permite navegação infinita
    slidesToShow: 1, // Quantidade de slides visíveis de cada vez
    slidesToScroll: 1 // Quantidade de slides a rolar de cada vez
  });
});