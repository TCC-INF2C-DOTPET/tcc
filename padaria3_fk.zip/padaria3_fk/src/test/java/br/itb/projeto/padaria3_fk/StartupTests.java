package br.itb.projeto.padaria3_fk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StartupTests {

	@Test
	void contextLoads() {
	}

}
