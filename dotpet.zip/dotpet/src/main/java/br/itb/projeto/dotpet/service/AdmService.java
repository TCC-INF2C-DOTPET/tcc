package br.itb.projeto.dotpet.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import br.itb.projeto.dotpet.model.entity.Adm;
import br.itb.projeto.dotpet.model.repository.AdmRepository;



@Service
public class AdmService {
	final AdmRepository admRepository;


	public AdmService(AdmRepository admRepository) {
		super();
		this.admRepository = admRepository;
		
	}
	
	@Transactional
	public Adm acessar(String email, String senha) {
		Adm adm = admRepository.findByEmail(email);

		if (adm != null) {
			if (adm.getSenha().equals(senha)) {
				return adm;
			}
		}

		return null;
	}

}
