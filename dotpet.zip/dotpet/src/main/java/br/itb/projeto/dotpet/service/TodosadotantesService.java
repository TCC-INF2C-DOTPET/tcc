package br.itb.projeto.dotpet.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Adotante;
import br.itb.projeto.dotpet.model.entity.Todosadotantes;
import br.itb.projeto.dotpet.model.repository.TodosadotantesRepository;



@Service
public class TodosadotantesService {

    private TodosadotantesRepository todosadotantesRepository;

    public TodosadotantesService(TodosadotantesRepository todosadotantesRepository) {
        this.todosadotantesRepository = todosadotantesRepository;
    }        

    public List<Todosadotantes> findAll() {
        return todosadotantesRepository.findAll();
    }

	public Todosadotantes salvarTodosadotantes(MultipartFile file, Todosadotantes todosadotantes) {
		if (todosadotantes.getNome() != null && !todosadotantes.getNome().isEmpty()) {
            
            return todosadotantesRepository.save(todosadotantes);
        } else {
            throw new IllegalArgumentException("O campo 'nome' é obrigatório.");
        }
	}



}

