package br.itb.projeto.dotpet.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Adocao;
import br.itb.projeto.dotpet.service.AdocaoService;

@Controller
@RequestMapping("/api/adocao")
public class AdocaoController {

    private final AdocaoService adocaoService;

    public AdocaoController(AdocaoService adocaoService) {
        this.adocaoService = adocaoService;
    }

    @GetMapping("/novo")
    public String novo(ModelMap model) {
        model.addAttribute("adocao", new Adocao());
        return "adoc-cad-ADM";
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Adocao> adicionarAdocao(MultipartFile file, @ModelAttribute Adocao adocao) {
        try {
            Adocao adocaoSalvo = adocaoService.salvarAdocao(file, adocao);
            return ResponseEntity.ok(adocaoSalvo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }}