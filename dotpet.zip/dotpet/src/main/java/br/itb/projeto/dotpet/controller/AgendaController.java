package br.itb.projeto.dotpet.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Agenda;
import br.itb.projeto.dotpet.service.AgendaService;

@Controller
@RequestMapping("/api/agenda")
public class AgendaController {

    private final AgendaService agendaService;

    public AgendaController(AgendaService agendaService) {
        this.agendaService = agendaService;
    }

    @GetMapping("/novo")
    public String novo(ModelMap model) {
        model.addAttribute("agenda", new Agenda());
        return "Agenda";
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Agenda> adicionarAgenda(MultipartFile file, @ModelAttribute Agenda agenda) {
        try {
        	Agenda agendaSalvo = agendaService.salvarAgenda(file, agenda);
            return ResponseEntity.ok(agendaSalvo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }}