package br.itb.projeto.dotpet.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Adotante;
import br.itb.projeto.dotpet.model.entity.Todosadotantes;
import br.itb.projeto.dotpet.service.AdotanteService;
import br.itb.projeto.dotpet.service.TodosadotantesService;

@Controller
@RequestMapping("/api/Todosadotantes")
public class TodosadotantesController {

    private final TodosadotantesService todosadotantesService;
    
    private final AdotanteService adotanteService;

    public TodosadotantesController(TodosadotantesService catalogotodoService, AdotanteService adotanteService) {
		super();
		this.todosadotantesService = catalogotodoService;
		this.adotanteService = adotanteService;
		
		
	}
    
    
    

    @GetMapping("/novo")
    public String novo(ModelMap model) {
        model.addAttribute("todosadotantes", new Todosadotantes()); 
        return "Todosadotantes";
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Todosadotantes> adicionarTodosadotantes(MultipartFile file, @ModelAttribute Todosadotantes todosadotantes) {
        try {
        	Todosadotantes todosadotantesSalvo = todosadotantesService.salvarTodosadotantes(file, todosadotantes);
            return ResponseEntity.ok(todosadotantesSalvo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
    

    @GetMapping("/lista")
    public String verListaadotantes(ModelMap model) {
        List<Adotante> adotantes = adotanteService.findAll();
        model.addAttribute("adotantes", adotantes);
        return "Todosadotantes";
    }
}
	
	
