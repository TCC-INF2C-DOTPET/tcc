package br.itb.projeto.dotpet.controller;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Animal;
import br.itb.projeto.dotpet.service.AnimalService;


@Controller
@RequestMapping("/api/animais")
public class AnimalController {
	
    private final AnimalService animalService;

    public AnimalController(AnimalService animalService) {
        this.animalService = animalService;
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Animal> adicionarAnimal(@RequestBody Animal animal) {
        Animal animalSalvo = animalService.salvarAnimal(null, animal);
        return ResponseEntity.ok(animalSalvo);
    }
    
    @GetMapping("/novo")
    public String novo(ModelMap model) {

    	model.addAttribute("animal", new Animal());
    	
        return "catalog-ADM";
    }
    
    @PostMapping("/salvar")
    public String salvar(@RequestParam(value = "file", required = false) MultipartFile file,
    		@ModelAttribute("animal") Animal animal) {
       
    	animalService.salvarAnimal(file, animal);
    	
        return "redirect:/api/animais/novo";
    }
    
    @GetMapping("/catalogo")
    public String catalogo(ModelMap model) {
       
    	List<Animal> animais = animalService.findAll();
    	model.addAttribute("animais", animais);
    	
        return "catalog";
    }
}
