package br.itb.projeto.dotpet.model.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Agenda")


		public class Agenda{
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private long id;

	private String status_visita;
	private String data_visita;
    private String observacoes;
    
    
    @ManyToOne
    @JoinColumn(name="funcionario_id")
    private Funcionario funcionario;
    
	
	private String nome_visitante;
    private String telefone_visitante;
    private String cpf_visitante;
	
	
	
	 public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	
	
	
	public String getStatus_visita() {
		return status_visita;
	}
	
	public void setStatus_visita(String status_visita) {
		this.status_visita = status_visita;
	}
	
	
	
	public String getData_visita() {
		return data_visita;
	}
	public void setData_visita(String data_visita) {
		this.data_visita = data_visita;
	}
	public String getObservacoes() {
		return observacoes;
	}
	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}
	
	
	public Funcionario getFuncionario() {
		return funcionario;
	}
	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}
	
	
	public String getNome_visitante() {
		return nome_visitante;
	}
	public void setNome_visitante(String nome_visitante) {
		this.nome_visitante = nome_visitante;
	}
	public String getTelefone_visitante() {
		return telefone_visitante;
	}
	public void setTelefone_visitante(String telefone_visitante) {
		this.telefone_visitante = telefone_visitante;
	}
	public String getCpf_visitante() {
		return cpf_visitante;
	}
	public void setCpf_visitante(String cpf_visitante) {
		this.cpf_visitante = cpf_visitante;
	}
	    
	    

}
