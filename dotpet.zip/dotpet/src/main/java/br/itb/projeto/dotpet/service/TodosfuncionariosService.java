package br.itb.projeto.dotpet.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Funcionario;
import br.itb.projeto.dotpet.model.entity.Todosfuncionarios;
import br.itb.projeto.dotpet.model.repository.TodosfuncionariosRepository;



@Service
public class TodosfuncionariosService {

    private TodosfuncionariosRepository todosfuncionariosRepository;

    public TodosfuncionariosService(TodosfuncionariosRepository todosfuncionariosRepository) {
        this.todosfuncionariosRepository = todosfuncionariosRepository;
    }        

    public List<Todosfuncionarios> findAll() {
        return todosfuncionariosRepository.findAll();
    }

	public Todosfuncionarios salvarTodosfuncionarios(MultipartFile file, Todosfuncionarios todosfuncionarios) {
		if (todosfuncionarios.getNome() != null && !todosfuncionarios.getNome().isEmpty()) {
            
            return todosfuncionariosRepository.save(todosfuncionarios);
        } else {
            throw new IllegalArgumentException("O campo 'nome' é obrigatório.");
        }
	}



}

