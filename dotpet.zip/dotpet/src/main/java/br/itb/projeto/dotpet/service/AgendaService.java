package br.itb.projeto.dotpet.service;


import java.io.IOException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Agenda;
import br.itb.projeto.dotpet.model.repository.AgendaRepository;



@Service
public class AgendaService {

	private AgendaRepository agendaRepository;
	
	
	public AgendaService(AgendaRepository agendaRepository) {
		super();
		this.agendaRepository = agendaRepository;
	}


	public Agenda salvarAgenda(MultipartFile file, Agenda agenda) {
	    if (agenda.getObservacoes() != null && !agenda.getObservacoes().isEmpty()) {
	        agenda.setStatus_visita("Ativo"); // Define o status da visita para "Ativo"
	        return agendaRepository.save(agenda);
	    } else {
	        throw new IllegalArgumentException("O campo 'nome' é obrigatório.");
	    }
	}

	

	public List<Agenda> findAll() {
		return agendaRepository.findAll();
	}


	public Agenda findById(long id) {
		return agendaRepository.findById(id).get();
	}
	
	@Transactional
	public void inativarAgenda(Agenda agenda) {

		Agenda _agenda = agenda;
		
		_agenda.setStatus_visita("Inativo");
		agendaRepository.save(_agenda);
	}
	
	@Transactional
	public void AtivarAgenda(Agenda agenda) {

		Agenda _agenda = agenda;
		
		_agenda.setStatus_visita("Ativo");
		agendaRepository.save(_agenda);
	}


	
}

	
