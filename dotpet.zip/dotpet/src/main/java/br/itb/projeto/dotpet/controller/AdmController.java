package br.itb.projeto.dotpet.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.itb.projeto.dotpet.model.entity.Adm;
import br.itb.projeto.dotpet.model.entity.Funcionario;
import br.itb.projeto.dotpet.service.AdmService;

@Controller
@RequestMapping("/api/adm")
public class AdmController {
	
	private AdmService admService;
	
	public AdmController(AdmService admService) {
		super();
		this.admService = admService;
	}

	@GetMapping("/login")
	    public String novo(ModelMap model) {
	        model.addAttribute("adm", new Adm());
	        return "login-adm";
	    }
	  
	  @PostMapping("/logar")
		public String Acessar(ModelMap map, @RequestParam("email") String email, @RequestParam("senha") String senha,
				HttpSession session) {

			Adm admlogado = admService.acessar(email, senha);

			if (admlogado != null) {
				session.setAttribute("admlogado", admlogado);
				
					return "redirect:/api/catalogotodo/lista";
				
			}

			return "redirect:/api/adm/login";
		}


}
