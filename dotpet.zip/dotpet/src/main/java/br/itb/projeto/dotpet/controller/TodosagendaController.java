package br.itb.projeto.dotpet.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Agenda;
import br.itb.projeto.dotpet.model.entity.Todosagenda;
import br.itb.projeto.dotpet.service.AgendaService;
import br.itb.projeto.dotpet.service.TodosagendaService;

@Controller
@RequestMapping("/api/Todosagenda")
public class TodosagendaController {

    private final TodosagendaService todosagendaService;
    
    private final AgendaService agendaService;

    public TodosagendaController(TodosagendaService catalogotodoService, AgendaService agendaService) {
		super();
		this.todosagendaService = catalogotodoService;
		this.agendaService = agendaService;
		
		
	}
    
    
    

    @GetMapping("/novo")
    public String novo(ModelMap model) {
        model.addAttribute("todosagenda", new Todosagenda()); 
        return "Todosagenda";
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Todosagenda> adicionarTodosagenda(MultipartFile file, @ModelAttribute Todosagenda todosagenda) {
        try {
        	Todosagenda todosagendaSalvo = todosagendaService.salvarTodosagenda(file, todosagenda);
            return ResponseEntity.ok(todosagendaSalvo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
    

    @GetMapping("/lista")
    public String verListaadotantes(ModelMap model) {
        List<Agenda> agendas = agendaService.findAll();
        model.addAttribute("agendas", agendas);
        return "Todosagenda";
    }
}
	
	
