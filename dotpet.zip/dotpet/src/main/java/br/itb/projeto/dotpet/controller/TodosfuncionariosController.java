package br.itb.projeto.dotpet.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Funcionario;
import br.itb.projeto.dotpet.model.entity.Todosfuncionarios;
import br.itb.projeto.dotpet.service.FuncionarioService;
import br.itb.projeto.dotpet.service.TodosfuncionariosService;

@Controller
@RequestMapping("/api/Todosfuncionarios")
public class TodosfuncionariosController {

    private final TodosfuncionariosService todosfuncionariosService;
    
    private final FuncionarioService funcionarioService;

    public TodosfuncionariosController(TodosfuncionariosService catalogotodoService, FuncionarioService funcionarioService) {
		super();
		this.todosfuncionariosService = catalogotodoService;
		this.funcionarioService = funcionarioService;
		
		
	}
    
    
    

    @GetMapping("/novo")
    public String novo(ModelMap model) {
        model.addAttribute("todosfuncionarios", new Todosfuncionarios()); // Corrigido para "todosfuncionarios"
        return "funcionariosTODOS";
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Todosfuncionarios> adicionarTodosfuncionarios(MultipartFile file, @ModelAttribute Todosfuncionarios todosfuncionarios) {
        try {
        	Todosfuncionarios todosfuncionariosSalvo = todosfuncionariosService.salvarTodosfuncionarios(file, todosfuncionarios);
            return ResponseEntity.ok(todosfuncionariosSalvo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
    

    @GetMapping("/lista")
    public String verListafuncionarios(ModelMap model) {
        List<Funcionario> funcionarios = funcionarioService.findAll();
        model.addAttribute("funcionarios", funcionarios);
        return "funcionariosTODOS";
    }
}
	
	
