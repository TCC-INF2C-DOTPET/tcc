package br.itb.projeto.dotpet.model.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.itb.projeto.dotpet.model.entity.Animal;

@Repository
public interface AnimalRepository extends JpaRepository<Animal, Long> {
}
