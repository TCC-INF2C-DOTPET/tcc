package br.itb.projeto.dotpet.model.entity;

public class Todosadocao {

}
