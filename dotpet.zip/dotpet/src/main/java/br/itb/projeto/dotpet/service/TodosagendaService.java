package br.itb.projeto.dotpet.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Agenda;
import br.itb.projeto.dotpet.model.entity.Todosagenda;
import br.itb.projeto.dotpet.model.repository.TodosagendaRepository;



@Service
public class TodosagendaService {

    private TodosagendaRepository todosagendaRepository;

    public TodosagendaService(TodosagendaRepository todosagendaRepository) {
        this.todosagendaRepository = todosagendaRepository;
    }        

    public List<Todosagenda> findAll() {
        return todosagendaRepository.findAll();
    }

	public Todosagenda salvarTodosagenda(MultipartFile file, Todosagenda todosagenda) {
		if (todosagenda.getData_visita() != null && !todosagenda.getData_visita().isEmpty()) {
            
            return todosagendaRepository.save(todosagenda);
        } else {
            throw new IllegalArgumentException("O campo 'nome' é obrigatório.");
        }
	}



}

