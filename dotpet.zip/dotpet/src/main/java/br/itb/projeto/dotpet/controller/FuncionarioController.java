package br.itb.projeto.dotpet.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Funcionario;
import br.itb.projeto.dotpet.service.FuncionarioService;

@Controller
@RequestMapping("/api/funcionarios")
public class FuncionarioController {

    private final FuncionarioService funcionarioService;

    public FuncionarioController(FuncionarioService funcionarioService) {
        this.funcionarioService = funcionarioService;
    }

    @GetMapping("/novo")
    public String novo(ModelMap model) {
        model.addAttribute("funcionario", new Funcionario());
        return "Func_cad-ADM";
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Funcionario> adicionarFuncionario(MultipartFile file, @ModelAttribute Funcionario funcionario) {
        try {
            Funcionario funcionarioSalvo = funcionarioService.salvarFuncionario(file, funcionario);
            return ResponseEntity.ok(funcionarioSalvo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
}
