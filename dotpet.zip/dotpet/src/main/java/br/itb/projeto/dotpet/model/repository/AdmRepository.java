package br.itb.projeto.dotpet.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.itb.projeto.dotpet.model.entity.Adm;

@Repository
public interface AdmRepository extends JpaRepository<Adm, Long> {
	Adm findByEmail(String email);

}
