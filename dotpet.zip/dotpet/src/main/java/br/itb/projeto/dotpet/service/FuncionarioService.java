package br.itb.projeto.dotpet.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Funcionario;
import br.itb.projeto.dotpet.model.repository.FuncionarioRepository;



@Service
public class FuncionarioService {

    private FuncionarioRepository funcionarioRepository;

    public FuncionarioService(FuncionarioRepository funcionarioRepository) {
        this.funcionarioRepository = funcionarioRepository;
    }        

    public List<Funcionario> findAll() {
        return funcionarioRepository.findAll();
    }

	public Funcionario salvarFuncionario(MultipartFile file, Funcionario funcionario) {
		if (funcionario.getNome() != null && !funcionario.getNome().isEmpty()) {
            
            return funcionarioRepository.save(funcionario);
        } else {
            throw new IllegalArgumentException("O campo 'nome' é obrigatório.");
        }
	}}

