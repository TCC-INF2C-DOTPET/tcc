package br.itb.projeto.dotpet.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Adocao;
import br.itb.projeto.dotpet.model.entity.Todosadocao;
import br.itb.projeto.dotpet.service.AdocaoService;
import br.itb.projeto.dotpet.service.TodosadocaoService;

@Controller
@RequestMapping("/api/Todosadocao")
public class TodosadocaoController {

    private final TodosadocaoService todosadocaoService;
    
    private final AdocaoService adocaoService;

    public TodosadocaoController(TodosadocaoService catalogotodoService, AdocaoService adocaoService) {
		super();
		this.todosadocaoService = catalogotodoService;
		this.adocaoService = adocaoService;
		
		
	}
    
    
    

    @GetMapping("/novo")
    public String novo(ModelMap model) {
        model.addAttribute("todosadocao", new Todosadocao()); 
        return "Todosadocao";
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Todosadocao> adicionarTodosadocao(MultipartFile file, @ModelAttribute Todosadocao todosadocao) {
        try {
        	Todosadocao todosadocaoSalvo = todosadocaoService.salvarTodosadocao(file, todosadocao);
            return ResponseEntity.ok(todosadocaoSalvo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
    

    @GetMapping("/lista")
    public String verListaadocao(ModelMap model) {
        List<Adocao> adocaos = adocaoService.findAll();
        model.addAttribute("adocaos", adocaos);
        return "Todosadocao";
    }
}
	
	
