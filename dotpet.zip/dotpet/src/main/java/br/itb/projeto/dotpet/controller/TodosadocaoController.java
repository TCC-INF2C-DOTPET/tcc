package br.itb.projeto.dotpet.controller;

public class TodosadocaoController {

}
