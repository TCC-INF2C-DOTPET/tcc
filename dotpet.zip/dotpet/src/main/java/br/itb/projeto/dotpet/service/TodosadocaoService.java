package br.itb.projeto.dotpet.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Adocao;
import br.itb.projeto.dotpet.model.entity.Todosadocao;
import br.itb.projeto.dotpet.model.repository.TodosadocaoRepository;



@Service
public class TodosadocaoService {

    private TodosadocaoRepository todosadocaoRepository;

    public TodosadocaoService(TodosadocaoRepository todosadocaoRepository) {
        this.todosadocaoRepository = todosadocaoRepository;
    }        

    public List<Todosadocao> findAll() {
        return todosadocaoRepository.findAll();
    }

	public Todosadocao salvarTodosadocao(MultipartFile file, Todosadocao todosadocao) {
		if (todosadocao.getAnimal_id() != null && !todosadocao.getAnimal_id().isEmpty()) {
            
            return todosadocaoRepository.save(todosadocao);
        } else {
            throw new IllegalArgumentException("O campo 'nome' é obrigatório.");
        }
	}



}

