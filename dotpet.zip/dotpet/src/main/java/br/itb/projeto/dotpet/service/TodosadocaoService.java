package br.itb.projeto.dotpet.service;

public class TodosadocaoService {

}
