package br.itb.projeto.dotpet.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import br.itb.projeto.dotpet.model.entity.Animal;
import br.itb.projeto.dotpet.model.entity.Catalogotodo;
import br.itb.projeto.dotpet.service.AnimalService;
import br.itb.projeto.dotpet.service.CatalogotodoService;

@Controller
@RequestMapping("/api/catalogotodo")
public class CatalogotodoController {

    private final CatalogotodoService catalogotodoService;
    
    private final AnimalService animalService;

    public CatalogotodoController(CatalogotodoService catalogotodoService, AnimalService animalService) {
		super();
		this.catalogotodoService = catalogotodoService;
		this.animalService = animalService;
	}
    
    private String noImage = "/images/filhote2.jpeg";

	@GetMapping("/novo")
    public String novo(ModelMap model) {
        model.addAttribute("catalogotodo", new Catalogotodo());
        return "catalogTODOS-ADM";
    }

    @PostMapping("/adicionar")
    public ResponseEntity<Catalogotodo> adicionarCatalagotodo(MultipartFile file, @ModelAttribute Catalogotodo catalogotodo) {
        try {
        	Catalogotodo catalogoSalvo = catalogotodoService.salvarCatalogotodo(file, catalogotodo);
            return ResponseEntity.ok(catalogoSalvo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
    

	@GetMapping("/lista")
	public String verListaAnimais(ModelMap model) {

		List<Animal> animais = animalService.findAll();
		model.addAttribute("animais", animais);
		model.addAttribute("noImage", noImage);

		return "catalogTODOS-ADM";
	}
	
	@GetMapping("/showImage/{id}")
	@ResponseBody
	public void showImage(
			@PathVariable("id") long id, HttpServletResponse response, Animal animal)
			throws ServletException, IOException {

		animal = animalService.findById(id);

		response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
		if (animal.getFoto() != null) {
			response.getOutputStream().write(animal.getFoto());
		} else {
			response.getOutputStream().write(null);
		}

		response.getOutputStream().close();
	}
}
