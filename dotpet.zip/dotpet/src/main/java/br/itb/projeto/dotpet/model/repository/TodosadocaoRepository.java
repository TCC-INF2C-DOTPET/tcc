package br.itb.projeto.dotpet.model.repository;

public interface TodosadocaoRepository {

}
