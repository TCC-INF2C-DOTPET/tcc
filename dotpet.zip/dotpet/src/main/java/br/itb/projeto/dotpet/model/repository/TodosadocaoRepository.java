package br.itb.projeto.dotpet.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.itb.projeto.dotpet.model.entity.Todosadocao;


	
	@Repository
	public interface TodosadocaoRepository extends JpaRepository<Todosadocao, Long> {

}