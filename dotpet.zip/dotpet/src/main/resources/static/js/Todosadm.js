document.addEventListener('DOMContentLoaded', function() {
    const Adm = document.querySelectorAll('.Adm');

    Adm.forEach(function(Adm) {
        const data_visita = Adm.querySelector('.data_visita');
        const infoAdicional = Adm.querySelector('.info-adicional');

        data_visita.addEventListener('click', function() {
            const isHidden = infoAdicional.style.display === 'none' || infoAdicional.style.display === '';

            Adm.forEach(function(Adm) {
                const info = Adm.querySelector('.info-adicional');
                info.style.display = 'none';
            });

            if (isHidden) {
                infoAdicional.style.display = 'block';
            }
        });
    });
});
