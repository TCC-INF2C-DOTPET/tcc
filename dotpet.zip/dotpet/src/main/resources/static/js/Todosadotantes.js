document.addEventListener('DOMContentLoaded', function() {
    const adotantes = document.querySelectorAll('.adotantes');

    adotantes.forEach(function(adotante) {
        const data_visita = adotante.querySelector('.data_visita');
        const infoAdicional = adotante.querySelector('.info-adicional');

        data_visita.addEventListener('click', function() {
            const isHidden = infoAdicional.style.display === 'none' || infoAdicional.style.display === '';

            adotantes.forEach(function(adotante) {
                const info = adotante.querySelector('.info-adicional');
                info.style.display = 'none';
            });

            if (isHidden) {
                infoAdicional.style.display = 'block';
            }
        });
    });
});
