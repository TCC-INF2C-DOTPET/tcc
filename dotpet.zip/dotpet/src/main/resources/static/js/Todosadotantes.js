document.addEventListener('DOMContentLoaded', function() {
    const adotantes = document.querySelectorAll('.adotantes');

    adotantes.forEach(function(adotante) {
        const nome = adotante.querySelector('.nome');
        const infoAdicional = adotante.querySelector('.info-adicional');

        nome.addEventListener('click', function() {
            const isHidden = infoAdicional.style.display === 'none' || infoAdicional.style.display === '';

            adotantes.forEach(function(adotante) {
                const info = adotante.querySelector('.info-adicional');
                info.style.display = 'none';
            });

            if (isHidden) {
                infoAdicional.style.display = 'block';
            }
        });
    });
});
