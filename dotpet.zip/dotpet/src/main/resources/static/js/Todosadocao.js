document.addEventListener('DOMContentLoaded', function() {
    const adocaos = document.querySelectorAll('.adocaos');

    adocaos.forEach(function(adocao) {
        const nome = adocao.querySelector('.nome');
        const infoAdicional = adocao.querySelector('.info-adicional');

        nome.addEventListener('click', function() {
            const isHidden = infoAdicional.style.display === 'none' || infoAdicional.style.display === '';

            adocaos.forEach(function(adocao) {
                const info = adocao.querySelector('.info-adicional');
                info.style.display = 'none';
            });

            if (isHidden) {
                infoAdicional.style.display = 'block';
            }
        });
    });
});
