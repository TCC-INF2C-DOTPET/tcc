document.addEventListener('DOMContentLoaded', function() {
    const funcionarios = document.querySelectorAll('.funcionarios');

    funcionarios.forEach(function(funcionario) {
        const nome = funcionario.querySelector('.nome');
        const infoAdicional = funcionario.querySelector('.info-adicional');

        nome.addEventListener('click', function() {
            const isHidden = infoAdicional.style.display === 'none' || infoAdicional.style.display === '';

            funcionarios.forEach(function(funcionario) {
                const info = funcionario.querySelector('.info-adicional');
                info.style.display = 'none';
            });

            if (isHidden) {
                infoAdicional.style.display = 'block';
            }
        });
    });
});
